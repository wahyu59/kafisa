import React, { Component } from 'react';
import { View, StyleSheet } from 'react-native';
import { NavigationActions, StackActions } from 'react-navigation';
import { api_url, logo, settings } from '../config/Constants';
import * as colors from '../assets/css/Colors';
import { Image, StatusBar, Loader } from '../components/GeneralComponents';
import AsyncStorage from '@react-native-community/async-storage';
import axios from 'axios';
import { connect } from 'react-redux';
import { serviceActionPending, serviceActionError, serviceActionSuccess } from '../actions/SplashActions';

class Splash extends Component<Props>{

  async componentDidMount() {
    await this.settings();
    await this.home();
  }

  settings = async () => {
    this.props.serviceActionPending();
    await axios({
      method: 'get', 
      url: api_url + settings
    })
    .then(async response => {
        await this.props.serviceActionSuccess(response.data)
    })
    .catch(error => {
      //console.log(error);
      this.props.serviceActionError(error);
    });
  }

  home = async () => {
   const user_id = await AsyncStorage.getItem('user_id');
   const customer_name = await AsyncStorage.getItem('customer_name');
   global.currency = this.props.data.default_currency;
   if(user_id !== null){
      global.id = user_id;
      global.customer_name = customer_name;
      this.props
       .navigation
       .dispatch(StackActions.reset({
         index: 0,
         actions: [
           NavigationActions.navigate({
             routeName: 'Home'
           }),
         ],
      }))
   }else{
      global.id = '';
      this.props
       .navigation
       .dispatch(StackActions.reset({
         index: 0,
         actions: [
           NavigationActions.navigate({
             routeName: 'Login'
           }),
         ],
      }))
   }
  }

  render() {
    return (
      <View style={styles.container}>
        <View>
          <StatusBar />
        </View>
        <View style={styles.image_view} >
          <Image source={logo} />
        </View>
      </View>
    )
  }
}

function mapStateToProps(state){
  return{
    isLoding : state.splash.isLoding,
    error : state.splash.error,
    data : state.splash.data,
    message : state.splash.message,
    status : state.splash.status,
  };
}

const mapDispatchToProps = (dispatch) => ({
    serviceActionPending: () => dispatch(serviceActionPending()),
    serviceActionError: (error) => dispatch(serviceActionError(error)),
    serviceActionSuccess: (data) => dispatch(serviceActionSuccess(data))
});


export default connect(mapStateToProps,mapDispatchToProps)(Splash);


const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor:colors.theme_bg
  },
  image_view:{
    height:75, 
    width:225
  }
});
