import React, {Component} from 'react';
import { View, StyleSheet, Text, ScrollView, ImageBackground, TouchableOpacity } from 'react-native';
import { StatusBar, Loader } from '../components/GeneralComponents';
import { img_url, api_url, service } from '../config/Constants';
import * as colors from '../assets/css/Colors';

import axios from 'axios';
import { connect } from 'react-redux';
import { serviceActionPending, serviceActionError, serviceActionSuccess } from '../actions/HomeActions';
import { productListReset } from '../actions/ProductActions';
class Home extends Component<Props>{

  constructor(props) {
      super(props)
      this.Service(); 
  }

  product = async (id,service_name) => {
    await this.props.productListReset();
    await this.props.navigation.navigate('Product',{ id:id, service_name:service_name });
  }

  Service = async () => {
    this.props.serviceActionPending();
    await axios({
      method: 'get', 
      url: api_url + service
    })
    .then(async response => {
        await this.props.serviceActionSuccess(response.data)
    })
    .catch(error => {
        this.props.serviceActionError(error);
    });
  }

  render() {
    
    const { isLoding, error, data, message, status } = this.props

    const service_list = data.map((row) => {
      service_image = img_url + row.image;
      return (
        <ImageBackground  source={{uri : service_image }} style={styles.background_image} >
          <TouchableOpacity activeOpacity={1} onPress={() => this.product(row.id, row.service_name)}  style={styles.touchable_opacity} >
            <Text style={styles.service_name} >{row.service_name}</Text>
          </TouchableOpacity>
        </ImageBackground>
      )
    })

    return (
      <View style={styles.container}>
        <View>
          <StatusBar/>
        </View>
        <ScrollView>
          {service_list}
        </ScrollView>
        <Loader visible={isLoding} />
      </View>
    )
  }
}

function mapStateToProps(state){
  return{
    isLoding : state.home.isLoding,
    error : state.home.error,
    data : state.home.data,
    message : state.home.message,
    status : state.home.status,
  };
}

const mapDispatchToProps = (dispatch) => ({
    serviceActionPending: () => dispatch(serviceActionPending()),
    serviceActionError: (error) => dispatch(serviceActionError(error)),
    serviceActionSuccess: (data) => dispatch(serviceActionSuccess(data)),
    productListReset: () => dispatch(productListReset())
});


export default connect(mapStateToProps,mapDispatchToProps)(Home);

const styles = StyleSheet.create({
  container: {
    backgroundColor:colors.theme_bg_two
  },
  background_image: {
    width:'100%', 
    height:170
  },
  touchable_opacity:{
    backgroundColor:colors.black_layer, 
    height:170, 
    alignItems:'center', 
    justifyContent:'center'
  },
  service_name:{
    color:colors.theme_bg_three, 
    fontSize:18, 
    fontWeight:'bold'
  },
  description:{
    color:colors.theme_bg_three,
    paddingLeft:10,
    paddingRight:10,
    textAlign:'center'
  }
});
