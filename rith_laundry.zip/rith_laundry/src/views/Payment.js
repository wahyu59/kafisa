import React, {Component} from 'react';
import { StyleSheet, View } from 'react-native';
import { Container, Header, Content, Left, Body, Right, Title, Button as Btn, Icon, Footer } from 'native-base';
import { api_url, place_order } from '../config/Constants';
import { NavigationActions } from 'react-navigation';
import * as colors from '../assets/css/Colors';
import { Loader } from '../components/GeneralComponents';
import { Button } from 'react-native-elements';
import axios from 'axios';
import { connect } from 'react-redux';
import { orderServicePending, orderServiceError, orderServiceSuccess } from '../actions/PaymentActions';
import { reset } from '../actions/CartActions';
import { productReset } from '../actions/ProductActions';
import RadioForm from 'react-native-simple-radio-button';

var radio_props = [
  {label: 'Cash', value: 1 }
];

class Payment extends Component<Props> {

  constructor(props) {
      super(props)
      this.handleBackButtonClick = this.handleBackButtonClick.bind(this);
      this.select_payment_method = this.select_payment_method.bind(this);
      this.state={
        payment_mode:1
      }
  }

  handleBackButtonClick= () => {
      this.props.navigation.goBack(null);
  }

  place_order = async () => {
    this.props.orderServicePending();
    await axios({
      method: 'post', 
      url: api_url + place_order,
      data:{ customer_id: global.id, payment_mode: this.state.payment_mode, address_id:this.props.address, expected_delivery_date:this.props.delivery_date, total:this.props.total, discount:this.props.discount, sub_total:this.props.sub_total, promo_id:this.props.promo_id, items: JSON.stringify(Object.values(this.props.items)) }
    })
    .then(async response => {
      await this.props.orderServiceSuccess(response.data);
      await this.move_orders();
    })
    .catch(error => {
      this.props.orderServiceError(error);
    });
  }

  async move_orders(){
    await this.props.reset();
    await this.props.productReset();
    const navigateAction = NavigationActions.navigate({
      routeName: 'MyOrders'
    });
    this.props.navigation.dispatch(navigateAction);
  }

  select_payment_method(){
    //select your payment
  }

  render() {

    const { isLoding, error, data, message, status } = this.props

    return (
      <Container>
        <Header androidStatusBarColor={colors.theme_bg} style={styles.header} >
          <Left style={{ flex: 1 }} >
            <Btn onPress={this.handleBackButtonClick} transparent>
              <Icon style={styles.icon} name='arrow-back' />
            </Btn>
          </Left>
          <Body style={styles.heading} >
            <Title style={styles.title} >Payment Mode</Title>
          </Body>
          <Right />
        </Header>
        <Content style={{ padding:20 }} >
          <RadioForm
            radio_props={radio_props}
            initial={0}
            animation={true}
            onPress={this.select_payment_method}
            labelStyle={styles.radio_style}
          />
        </Content>
        <Footer style={styles.footer} >
          <View style={styles.footer_content}>
            <Button
              onPress={this.place_order}
              title="Place Order"
              buttonStyle={styles.place_order}
            />
          </View>
        </Footer>
        <Loader visible={isLoding} />
      </Container>
    );
  }
}

function mapStateToProps(state){
  return{
    isLoding : state.payment.isLoding,
    error : state.payment.error,
    data : state.payment.data,
    message : state.payment.message,
    status : state.payment.status,
    address : state.cart.address,
    delivery_date : state.cart.delivery_date,
    total : state.cart.total_amount,
    sub_total : state.cart.sub_total,
    discount : state.cart.promo_amount,
    promo_id : state.cart.promo_id,
    items : state.product.cart_items
  };
}

const mapDispatchToProps = (dispatch) => ({
    orderServicePending: () => dispatch(orderServicePending()),
    orderServiceError: (error) => dispatch(orderServiceError(error)),
    orderServiceSuccess: (data) => dispatch(orderServiceSuccess(data)),
    reset: () => dispatch(reset()),
    productReset: () => dispatch(productReset())
});


export default connect(mapStateToProps,mapDispatchToProps)(Payment);

const styles = StyleSheet.create({
  header:{
    backgroundColor:colors.theme_bg_three
  },
  icon:{
    color:colors.theme_fg_two
  },
  header_body: {
    flex: 3,
    justifyContent: 'center'
  },
  title:{
    alignSelf:'center', 
    color:colors.theme_fg_two,
    alignSelf:'center', 
    fontSize:16, 
    fontWeight:'bold'
  },
  radio_style:{
    marginLeft:20, 
    fontSize: 17, 
    color: colors.theme_bg, 
    fontWeight:'bold'
  },
  footer:{
    backgroundColor:'transparent'
  },
  footer_content:{
    width:'90%'
  },
  place_order:{
    backgroundColor:colors.theme_bg
  }
});
