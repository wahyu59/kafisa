import React, {Fragment} from 'react';
import { createStackNavigator, createAppContainer } from 'react-navigation';
import { fromRight } from 'react-navigation-transitions';
import { createMaterialBottomTabNavigator } from "react-navigation-material-bottom-tabs";
import Icon from 'react-native-vector-icons/Ionicons';

/* Screens */
import Splash from './src/views/Splash';
import Home from './src/views/Home';
import Product from './src/views/Product';
import Promo from './src/views/Promo';
import MyOrders from './src/views/MyOrders';
import OrderDetails from './src/views/OrderDetails';
import Cart from './src/views/Cart';
import Profile from './src/views/Profile';
import More from './src/views/More';
import Address from './src/views/Address';
import AddressList from './src/views/AddressList';
import Payment from './src/views/Payment';
import Login from './src/views/Login';
import Register from './src/views/Register';
import Faq from './src/views/Faq';
import FaqDetails from './src/views/FaqDetails';
import PrivacyPolicy from './src/views/PrivacyPolicy';
import Forgot from './src/views/Forgot';
import Otp from './src/views/Otp';
import Reset from './src/views/Reset';
import Logout from './src/views/Logout';

const TabNavigator = createMaterialBottomTabNavigator({
  Home: { 
    screen: Home,
    navigationOptions:{
      tabBarLabel:'Home',
      tabBarIcon:({tintColor}) => (
        <Icon name='ios-home' color={tintColor} size={24} />
      )
    } },
  MyOrders: { 
    screen: MyOrders,
    navigationOptions:{
      tabBarLabel:'My Orders',
      tabBarIcon:({tintColor}) => (
        <Icon name='ios-shirt' color={tintColor} size={24} />
      )
    } },
  Profile: { 
  screen: Profile,
  navigationOptions:{
    tabBarLabel:'Profile',
    tabBarIcon:({tintColor}) => (
      <Icon name='ios-person' color={tintColor} size={24} />
    )
  } },
  More: { 
  screen: More,
  navigationOptions:{
    tabBarLabel:'More',
    tabBarIcon:({tintColor}) => (
      <Icon name='ios-more' color={tintColor} size={24} />
    )
  } }
}, {
  initialRouteName: 'Home',
  //activeColor: '#FFFFFF',
  //inactiveTintColor: '#FFFFFF',
  //inactiveColor: '#3e2465',
  shifting: false,
  barStyle: { backgroundColor: '#115e7a' },
});

const AppNavigator = createStackNavigator({

  Splash: { screen: Splash },
  Home: { screen: TabNavigator, navigationOptions: {
        header: null
      } },
  Product: { screen: Product },
  Cart: { screen: Cart },
  Address: { screen: Address },
  AddressList: { screen: AddressList },
  Payment: { screen: Payment },
  Promo: { screen: Promo },
  OrderDetails: { screen: OrderDetails },
  Login: { screen: Login },
  Register: { screen: Register },
  Faq: { screen: Faq },
  FaqDetails: { screen: FaqDetails },
  PrivacyPolicy: { screen: PrivacyPolicy },
  Forgot: { screen: Forgot },
  Otp: { screen: Otp },
  Reset: { screen: Reset },
  Logout: { screen: Logout }
  },{
  initialRouteName:'Splash',
  headerMode: 'none',
  navigationOptions: {
      headerVisible: false,
  },
  transitionConfig: () => fromRight(500)
});

export default createAppContainer(AppNavigator);

